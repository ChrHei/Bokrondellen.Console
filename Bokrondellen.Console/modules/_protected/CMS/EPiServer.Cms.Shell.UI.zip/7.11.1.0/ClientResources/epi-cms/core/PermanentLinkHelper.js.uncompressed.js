﻿define("epi-cms/core/PermanentLinkHelper", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/Deferred",
    "dojo/_base/lang",

    "dojo/store/Memory",
    "dojo/when",

// epi
    "epi/dependency",
    "epi/Url",
    "epi-cms/ApplicationSettings",
    "epi-cms/core/ContentReference"
],

function (
// dojo
    declare,
    Deferred,
    lang,

    Memory,
    when,

// epi
    dependency,
    Url,
    ApplicationSettings,
    ContentReference
) {
    // summary:
    //      Upgrade permanent link from simple string to object
    // tags:
    //      public
    var PermanentLinkHelper = {

        // _cacheStore: dojo/store/Memory
        //      Store contents that already got before.
        _cacheStore: new Memory({ idAttribute: "id", data: [] }),

        _storeCache: function (/*Object*/content) {
            // summary:
            //      Store the content in to cache.
            // tags:
            //      private

            if (!content) {
                return;
            }

            // If already exist, return immediately
            var cachedObj = this._cacheStore.get(content.contentLink);
            if (cachedObj) {
                return;
            }

            // Store mapping (contentlink, internalLink) into cache
            this._cacheStore.put({
                id: content.contentLink,
                internalLink: this._toInternal(content)
            });
        },

        _tryGetContentLink: function(/*String*/link) {
            // summary:
            //      Try get content link from the link. Its maybe:
            //          + Uri with id in query ("/HeadAlloy/ProductPageTemplate.aspx?id=1")
            //          + ContentReference ("192_168")
            // tags:
            //      private

            if (!link) {
                return null;
            }

            // Try get id from query first
            var url = new Url(link),
                contentLink = url.query["id"];
            if (!contentLink) {
                try {
                    contentLink = ContentReference.toContentReference(link);
                    if (isNaN(contentLink.id)) {
                        return null;
                    }
                    return contentLink.toString();

                } catch (e) {
                    // Don't need to log the error
                    return null;
                }
            }

            return contentLink;
        },

        _toInternal: function (/*Object*/content) {
            // summary:
            //      Return a link with friendly URL (without id)
            // tags:
            //      private

            var permanentLink,
                applicationVirtualPath = ApplicationSettings.applicationVirtualPath || "";

            if (content) {
                permanentLink = applicationVirtualPath + "/link/" + content.contentGuid.replace(/-/g, "") + ".aspx";
                // In case we don't have application virtual path name, replace "//" to "/"
                // ex:
                //      before: "//link/{contentGuid}.aspx"
                //      after: "/link/{contentGuid}.aspx"
                permanentLink = permanentLink.replace(/\/\//g, "\/");
            }

            return permanentLink;
        },

        toPermanentLink : function (/*Object*/content, /*String*/mode) {
            // summary:
            //      Converts a content data object to it's permanent link form.
            // description:
            //      The link created will be in the format "/link/{contentGuid}.aspx". Since everything
            //      is now content all links can be resolved with the .aspx extension.
            // tags:
            //      public

            // try creat a mapping
            this._storeCache(content);

            // return value
            return this._toInternal(content);
        },

        isPermanentLink: function (/*String*/link) {
            // summary:
            //      Test whether given string is in permanent link format
            // tags:
            //      public

            // If the link contains "/link/" and follow with "<guid>.aspx" then true otherwise false
            return (/(\/link\/)(?=([0-9a-z]{32})(\.aspx))/i).test(link);
        },

        getContent: function (/*String*/link, /*Object*/options) {
            // summary:
            //      Get linked content data with the permanent link
            // tags:
            //      public

            if (!link) {
                return null;
            }

            var dfd = new Deferred(),
                registry = dependency.resolve("epi.storeregistry"),
                store = registry.get("epi.cms.content.light"),
                query = lang.mixin({
                    "query": "getcontentbypermanentlink",
                    "permanentLink": link
                }, options || {}),
                results;

            var cachedObjects = this._cacheStore.query({ internalLink: link }),
                isCached = cachedObjects && cachedObjects.length > 0,
                isPermanentLink = this.isPermanentLink(link),
                // Try get content link incase it's not valid permanentlink format.
                // Should remove this after release 7.5, because the link with id in query string is no longer suppored.
                contentLink = isPermanentLink ? null : this._tryGetContentLink(link);

            // Give a chance to get content from cache by get method which is to increase performance
            results = isCached || contentLink ? store.get(contentLink || cachedObjects[0].id) : store.query(query);
            when(results, lang.hitch(this, function (contents) {

                var content = contents && contents instanceof Array ? contents[0] : contents;
                if (!isCached) {
                    this._storeCache(content);
                }

                dfd.resolve(content);

            }));

            return dfd;
        }
    };

    return PermanentLinkHelper;
});