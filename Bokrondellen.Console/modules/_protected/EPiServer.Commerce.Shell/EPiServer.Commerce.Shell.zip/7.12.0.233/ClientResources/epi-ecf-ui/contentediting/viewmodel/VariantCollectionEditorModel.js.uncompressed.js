﻿define("epi-ecf-ui/contentediting/viewmodel/VariantCollectionEditorModel", [
    // dojo
    "dojo/_base/declare",

    // ecf
    "./VariantCollectionReadOnlyEditorModel",
    "./_RelationCollectionEditorModelMixin",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.variantcollectioneditor"
],
function (
    //dojo
    declare,

    // ecf
    VariantCollectionReadOnlyEditorModel,
    _RelationCollectionEditorModelMixin,

    // Resources
    res
) {
    return declare([VariantCollectionReadOnlyEditorModel, _RelationCollectionEditorModelMixin], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/VariantCollectionEditEditorModel
        // summary:
        //      Represents the model for VariantCollectionEditor

        res: res
    });
});