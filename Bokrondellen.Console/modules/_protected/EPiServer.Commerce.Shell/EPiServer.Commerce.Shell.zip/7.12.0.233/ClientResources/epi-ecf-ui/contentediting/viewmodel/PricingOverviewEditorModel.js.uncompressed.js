﻿define("epi-ecf-ui/contentediting/viewmodel/PricingOverviewEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/currency",
    "dojo/when",
    "dojo/Stateful",
    "dojo/Evented",
    "dojo/promise/all",
    // dojox
    "dojox/html/entities",
    // epi
    "epi/shell/_StatefulGetterSetterMixin",
    "epi/shell/command/DelegateCommand",
    "epi/dependency",
    "epi/datetime",
    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    //dojo
    declare,
    lang,
    currency,
    when,
    Stateful,
    Evented,
    all,
    // dojox
    htmlEntities,
    // epi
    _StatefulGetterSetterMixin,
    DelegateCommand,
    dependency,
    epiDate,
    //resources
    resources,
    res
) {
    return declare([Stateful, _StatefulGetterSetterMixin, Evented], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/PricingOverviewEditorModel
        // summary:
        //      Represents the model for PricingOverviewEditor

        _storeKey: "epi.commerce.price",

        store: null,

        metadataManager: null,

        contentLink: null,

        marketId: null,

        priceCode: null,

        queryOptions: null,

        getChildrenQueryName: "getpricechildren",

        postscript: function () {
            this.inherited(arguments);

            this.storeRegistry = dependency.resolve("epi.storeregistry");
            this.store = this.store || this.storeRegistry.get(this._storeKey);

            this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
        },

        _createQueryOptions: function () {
            // summary:
            //      Creates and returns query options, based on selected content link, market id and customer group (if any).
            // tags:
            //      private

            var query = { referenceId : this.get("contentLink"), query: this.getChildrenQueryName },
                ignoreOptions = ["query", "referenceId"];

            if (this.get("marketId")) {
                lang.mixin(query, { marketId: this.get("marketId") });
                if (query.marketId === "ALL") {
                    ignoreOptions.push("marketId");
                }
            }

            if (this.get("priceCode")) {
                lang.mixin(query, { priceCode: this.get("priceCode") });
                if (query.priceCode === "ALL"){
                    ignoreOptions.push("priceCode");
                }
            }

            return { query: query, options: { ignore: ignoreOptions } };
        },

        getCommands: function (model, category) {
            var commonSettings = {
                category: category,
                model: model,
                canExecute: true,
                isAvailable: true
            };

            return [
                new DelegateCommand(lang.mixin({
                    name: "duplicate",
                    label: resources.commands.duplicate,
                    iconClass: "epi-iconDuplicatePage",
                    delegate: lang.hitch(this, function (cmd) {
                        this.emit("duplicateCommandEvent");
                    })
                }, commonSettings)),
                new DelegateCommand(lang.mixin({
                    name: "remove",
                    label: resources.commands.remove,
                    iconClass: "epi-iconClose",
                    delegate: lang.hitch(this, function (cmd) {
                        this.emit("removeCommandEvent");
                    })
                }, commonSettings))
            ];
        },

        addItem: function(item) {
            return when(this.store.add(item), lang.hitch(this, function(data) {
                this.emit("itemAdded", { id: data.id });
            }));
        },

        removeItems: function (models) {

            var promises = [];

            for (var i = 0, j = models.length; i < j; i += 1) {
                promises.push(this.store.remove(models[i].id));
            }

            return all(promises).then(lang.hitch(this, function(removed) {
                this.emit("itemsRemoved", { removedItems: removed });
            }));
        },

        generateFormatters: function (columnDefinitions) {

            columnDefinitions.validDate.formatter = lang.hitch(this, this._formatValidDate);
            columnDefinitions.unitPrice.formatter = function(value) {
                return currency.format(value.amount, { currency: value.currency });
            };
            columnDefinitions.priceCode.renderCell = function (object, value, cell, options) {
                cell.innerHTML = htmlEntities.encode(value);
            };
        },

        _formatValidDate: function (value) {
            // Format datetime
            return this._formatDate(value.validFrom) + " - " + this._formatDate(value.validUntil);
        },

        _formatDate: function (datetime) {
            // summary:
            //      Format datetime to short type.
            // datetime: Object
            //      The raw data.
            // tags:
            //      public

            return datetime && datetime !== "" ? epiDate.toUserFriendlyString(datetime) : res.untildatenotdefined;
        }
    });
});