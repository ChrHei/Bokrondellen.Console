﻿define("epi-ecf-ui/widget/PriceEditorButtons", [
    "dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/_base/array",
	"dojo/_base/Deferred",
    "dojo/dom-class",

    "dojo/on",
    "dojo/aspect",
    "put-selector/put",
    "dgrid/Grid",
    "dgrid/editor",

// Dijit
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dojo/Evented",
    "dijit/form/Button",

    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid.commands"

], function (
    declare,
    lang,
    array,
    Deferred,
    domClass,

    on,
    aspect,
    put,
    Grid,
    editor,

    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    Evented,
    Button,

    //resources
    resources
    ) {

    // editor column plugin function
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, Evented], {
        // summary:
        //		Adds editing capability to a column's cells.

        templateString: '<div class="epi-priceEditorButtons"></div>',

        commands: null,

        postMixInProperties: function () {
            this.inherited(arguments);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.commands = this.commands || this._setUpCommands();

            if (this.commands) {
                array.forEach(this.commands, lang.hitch(this, function (command) {
                    this._addButtonForCommand(command);
                }));
            }
        },

        _setUpCommands: function () {
            return [
                {
                    label: resources.save,
                    tooltip: resources.save,
                    canExecute: true,
                    execute: lang.hitch(this, function () {
                        this.savePrice();
                    })
                },
                {
                    label: resources.cancel,
                    tooltip: resources.cancel,
                    canExecute: true,
                    execute: lang.hitch(this, function () {
                        this.cancelEditing();
                    })
                }
            ];
        },

        savePrice: function () {
        },

        cancelEditing: function () {
        },

        _addButtonForCommand: function (command) {
            var button = new Button({
                label: command.label,
                title: command.tooltip,
                iconClass: command.iconClass
            });

            if (command.cssClass) {
                domClass.add(button.domNode, command.cssClass);
            }

            button.set("disabled", !command.canExecute);

            button.on("click", function () {
                command.execute();
            });

            button.placeAt(this.domNode);
            this.own(button);
        }
    });
});
