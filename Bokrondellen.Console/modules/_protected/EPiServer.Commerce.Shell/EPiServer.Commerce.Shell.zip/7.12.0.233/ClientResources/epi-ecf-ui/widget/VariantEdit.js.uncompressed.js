require({cache:{
'url:epi-ecf-ui/widget/templates/VariantEdit.html':"﻿<div>\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-cms/contentediting/StandardToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar\"></div>\r\n    <div data-dojo-attach-point=\"notificationBar\" data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-props=\"region:'top'\"></div>\r\n    \r\n    <div data-dojo-type=\"dijit/layout/ContentPane\" data-dojo-attach-point=\"contentPane\" class=\"epi-view-container\">\r\n        <h1>${resources.title}</h1>\r\n        <div data-dojo-attach-point=\"collectionList\" data-dojo-type=\"epi-ecf-ui/contentediting/editors/VariantCollectionEditor\"></div>\r\n        <div data-dojo-attach-point=\"dropContainer\" class=\"epi-content-area-actionscontainer\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/VariantEdit", [
// dojo
    "dojo/aspect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    
// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

// EPi Framework
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/dnd/Target",
    
// cms
    "epi-cms/widget/Breadcrumb",
    "epi-cms/widget/BreadcrumbCurrentItem",
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",

// commerce
    "../contentediting/editors/VariantCollectionEditor",
    "./_RelationViewBase",
    
// Resources
    "dojo/text!./templates/VariantEdit.html",
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.variantcollectioneditor",
// Widgets in the template
    "epi-cms/contentediting/NotificationBar",
    "epi-cms/contentediting/StandardToolbar"
], function (
// dojo
    aspect,
    declare,
    lang,
    topic,
    
// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

// EPi Framework
    _ModelBindingMixin,
    Target,

// CMS
    Breadcrumb,
    BreadcrumbCurrentItem,
    _TextWithActionLinksMixin,

// commerce
    VariantCollectionEditor,
    _RelationViewBase,

// Resources
    template,
    resources
) {

    return declare([_RelationViewBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _TextWithActionLinksMixin], {
        // summary:
        //    Represents the widget to edit variants.
        // tags:
        //    public
        templateString: template,
        
        _dndTarget: null,
        
        resources: resources,
        
        contentPane: this.contentPane,

        postCreate: function () {
            this.inherited(arguments);
            this.setupActionLinks(this.dropContainer);
        },

        buildRendering: function () {
            this.inherited(arguments);

            this._dndTarget = new Target(this.dropContainer, {
                accept: this.collectionList.allowedDndTypes,
                insertNodes: function () { }
            });

            this.own(aspect.after(this._dndTarget, "onDropData", lang.hitch(this, function (dndData) {
                this.collectionList._addItem(dndData[0], true);
            }), true));
        },

        updateView: function (data, context) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.inherited(arguments);
            this.set("value", context.id);
        },
        
        getTemplateString: function () {
            // summary:
            //      The template string for drop area
            // tags:
            //      protected

            return {
                templateString: this.resources.drophere,
                actions: this.resources.actions
            };
        },

        executeAction: function (actionName) {
            // summary:
            //      Called when [entries] link clicked
            // tags:
            //      public override

            topic.publish("/epi/layout/pinnable/tools/toggle", true);
        },

        _setValueAttr: function (value) {
            this.collectionList.set("value", value);
        }
    });
});
