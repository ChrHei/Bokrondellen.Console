﻿define("epi-ecf-ui/store/CompositeKey", [
    "dojo/_base/lang",
    "dojo/when"
    ],
function (lang, when) {

    // module:
    //		epi-ecf-ui/store/CompositeKey

    var CompositeKey = function (masterStore, keys, getClones) {
        return lang.delegate(masterStore, 
            {
                keys: keys,
                getClones: getClones,
                removeReAdd: function(object, directives) {
                    var newObj = lang.clone(object),
                        promise = this.remove(object[this.idProperty]);
                    delete newObj[this.idProperty];
                    return when(promise, function() {  // Wait for remove to finish before adding
                        return masterStore.add(newObj, directives);
                    });
                },
                put: function(object, directives) {
                    var oldObj = this.get(object[this.idProperty]);
                    if(oldObj && this.keys) {
                        for(var i=0, j=this.keys.length; i<j ; i+=1) {
                            if(oldObj[keys[i]] !== object[keys[i]]) {
                                return this.removeReAdd(object, directives);
                            }
                        }
                    }
                    return masterStore.put.apply(masterStore, arguments);
                },
                get: function(id) {
                    return getClones ? lang.clone(masterStore.get.apply(masterStore, arguments)) : masterStore.get.apply(masterStore, arguments);
                }
        });
    };

    /*=====
    
    CompositeKey = declare(Store, {
        // summary:
        //		The CompositeKey store looks for changes in attributes that make
        //		out composite keys and does a re-add if any of them have changed.
        // example:
        //	|	var master = new Memory(data);
        //	|	var store = new CompositeKey(master, cacher);
        //
        constructor: function(masterStore){
            // masterStore:
            //		This is the store that serves object with composite keys.
            // keys:
            //      These are the keys used to determine if key is invalid.
            // getClones:
            //      Decides whether the get method should deliver cloned objects, needed
            //      when implementations are running get before put.
        }
        put: function(object, directives){
            // summary:
            //		Put the object into the store, evaluating whether to do a delete/readd.
            // object: Object
            //		The object to put to the store.
            // directives: dojo/store/api/Store.PutDirectives?
            //		Any additional parameters needed to describe how the put should be performed.
            // returns: Promise
            //		Returns a promise for the result
        },
        removeReAdd: function(object){
            // summary:
            //		Remove the object with the specific id.
             // object: Object
            //		The object to remove and re-add to the store.
            // directives: dojo/store/api/Store.PutDirectives?
        }
    });
    =====*/

    return CompositeKey;
});
