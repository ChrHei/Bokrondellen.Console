﻿define("epi-ecf-ui/component/DeleteConfirmation", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
// dojox
    "dojox/widget/Standby",
// EPi
    "epi/shell/widget/dialog/Confirmation"
], function (
// Dojo
    declare,
    lang,
// dojox    
    Standby,
// EPi
    Confirmation
) {
    return declare([Confirmation], {

        _standBy: null,

        postCreate: function(){
            this.inherited(arguments);
            this._standBy = new Standby({ target: this.domNode, color: "#fff" }).placeAt(document.body);
            this._standBy.startup();
            this.own(this._standBy);
        },

        _onConfirm: function () {
            // summary:
            //		Called when user has triggered the dialog's confirm action.
            // type:
            //		callback
            
            this._standBy.show();
            for(var index in this.definitionConsumer._widgetMap){
                var widget = this.definitionConsumer._widgetMap[index];
                widget.set("disabled", true);
            }
            this.onAction(true);
        }
    });
});