require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/MoneyEditor.html':"﻿<div class=\"epi-moneyEditor\">\r\n    <div data-dojo-type=\"epi-cms/contentediting/editors/SelectionEditor\" data-dojo-attach-point=\"currency\" data-dojo-attach-event=\"onKeyDown: _handleKey\"></div>\r\n    <div data-dojo-type=\"dijit/form/NumberTextBox\" data-dojo-attach-point=\"amount\" data-dojo-attach-event=\"onKeyDown: _handleKey\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/MoneyEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/keys",
// dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/NumberTextBox",
    "dijit/focus",
// dojox
    "dojox/html/entities",
// epi
    "epi/epi",
// epi-cms
    "epi-cms/contentediting/editors/SelectionEditor",
// template
    "dojo/text!./templates/MoneyEditor.html"
], function (
// dojo
    declare,
    lang,
    array,
    keys,
// dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    NumberTextBox,
    focusUtil,
// dojox
    htmlEntities,
// epi
    epi,
// epi-cms
    SelectionEditor,
// template
    template
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // module:
        //  epi-ecf-ui/contentediting/editors/MoneyEditor
        // summary:
        //    Represents the widget to edit currency and amount.
        // tags:
        //    public

        templateString: template,

        value: null,

        _getValueAttr: function () {
            var oldValue = this.value;

            var newValue = {
                currency: this.currency.get("value"),
                amount: this.amount.get("value")
            };

            if (epi.areEqual(newValue, oldValue)){
                return oldValue;
            } else {
                return newValue;
            }
        },

        _setValueAttr: function(value){
            this._set("value", value);
            this.currency.set("value", value.currency);
            this.amount.set("value", value.amount);
        },

        _setSelectionsAttr: function (selections) {
            //TODO: this can be removed when bug 115958 is fixed
            var clonedSelections = lang.clone(selections);
            //Encode the values before setting to the dropdown list
            array.forEach(clonedSelections, function (selection, i) {
                clonedSelections[i].text = htmlEntities.encode(selection.text);
            });
            this.currency.set("selections", clonedSelections);
        },

        _handleKey: function (e) {
            if(e.keyCode === keys.ENTER){
                e.preventDefault();
                focusUtil.curNode.blur();
            }
        },

        focus: function(){
            this.amount.focus();
        },

        isValid: function () {
            return this.currency.isValid() && this.amount.isValid() && this.amount.value > 0;
        }
    });
});
