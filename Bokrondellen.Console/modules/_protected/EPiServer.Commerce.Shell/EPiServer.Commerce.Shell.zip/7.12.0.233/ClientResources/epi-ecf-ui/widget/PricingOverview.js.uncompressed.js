require({cache:{
'url:epi-ecf-ui/widget/templates/PricingOverview.html':"﻿<div class=\"epi-pricingOverview\">\r\n    <div data-dojo-attach-point=\"header\">\r\n        <div data-dojo-type=\"epi-cms/contentediting/NotificationBar\" data-dojo-attach-point=\"notificationBar\"></div>\r\n        <div class=\"epi-view-container\">\r\n            <h1 class=\"dijitInline\">${resources.heading}</h1>\r\n            <div class=\"epi-filterHolder\">\r\n                <div class=\"epi-filterHolderLeading\">\r\n                    <button class=\"epi-mediumButton\"\r\n                            data-dojo-attach-event='onClick: _onAddNewPrice'\r\n                            data-dojo-attach-point=\"addNewPrice\"\r\n                            data-dojo-type=\"dijit/form/Button\"\r\n                            data-dojo-props=\"label: '${resources.buttons.addprice}', title:'${resources.buttons.addprice}', iconClass:'epi-iconPlus'\"></button>\r\n                </div>\r\n                <div class=\"epi-filterHolderCenter clearfix\">\r\n                    <label for=\"customergroup\">${resources.selectors.customergroup}</label>\r\n                    <select name=\"customergroup\"\r\n                            data-dojo-type=\"dijit/form/Select\"\r\n                            data-dojo-attach-point=\"customerGroupSelector\"\r\n                            data-dojo-attach-event='onChange: _onCustomerGroupChanged'></select>\r\n                    <label for=\"markets\">${resources.selectors.market}</label>\r\n                    <select name=\"markets\"\r\n                            data-dojo-type=\"epi-ecf-ui/widget/MarketSelector\"\r\n                            data-dojo-attach-point=\"marketSelector\"\r\n                            data-dojo-attach-event='onChange: _onMarketChanged'></select>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <div data-dojo-attach-point='priceListNode'></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/PricingOverview", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/when",
    "dojo/dom",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/dom-style",

// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Select",
// dojox
    "dojox/html/entities",
// EPi Framework
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/TypeDescriptorManager",
// EPi CMS
    "epi-cms/contentediting/NotificationBar", // used in template
// commerce
    "../contentediting/editors/PricingOverviewEditor",
    "../contentediting/ModelSupport",
    "./BackToPreviousViewNotification",
    "./MarketSelector",
    "./viewmodel/PricingOverviewModel",
// Resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview",
    "epi/i18n!epi/cms/nls/commerce.widget.market",
    "epi/i18n!epi/cms/nls/commerce.widget.customergroup",
    "dojo/text!./templates/PricingOverview.html"
], function (
// dojo
    declare,
    lang,
    array,
    when,
    dom,
    domConstruct,
    domGeo,
    domStyle,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    Select,
// dojox
    entities,
// EPi Framework
    _ModelBindingMixin,
    TypeDescriptorManager,
// EPi CMS
    NotificationBar,
// commerce
    PricingOverviewEditor,
    ModelSupport,
    BackToPreviousViewNotification,
    MarketSelector,
    PricingOverviewModel,
// Resources
    resources,
    resDefaultMarket,
    resDefaultCustomerGroup,
    template
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //    Represents the widget to preview price for entries.
        // tags:
        //    public
        resources: resources,

        templateString: template,

        modelClassName: PricingOverviewModel,

        defaultCGItem: { id: "ALL", name: resDefaultCustomerGroup.defaultitem },

        _backToPreviousViewNotification: null,

        // Map property name in view model to a list of properties in this widget
        modelBindingMap: {
            "markets": ["markets"],
            "customerGroups": ["customerGroups"]
        },

        postCreate: function () {
            this.inherited(arguments);

            if (!this.model && this.modelClassName) {
                var modelClass = declare(this.modelClassName);
                this.set("model", new modelClass());
            }
            this.model.populateData(); // load market list and customer groups.

            this._backToPreviousViewNotification = new BackToPreviousViewNotification();
            this.own(
                this._backToPreviousViewNotification.watch("notification", lang.hitch(this, this._defaultNotificationWatchHandler))
            );
        },

        buildRendering: function() {
            this.inherited(arguments);

            this.priceList = new PricingOverviewEditor();
            this.own(this.priceList);
            domConstruct.place(this.priceList.domNode, this.priceListNode);
        },

        showNotification: function () {
            // summary:
            //      Displays notification bar
            // tags:
            //      public
            this._backToPreviousViewNotification.showNotification();
        },

        _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Add/remove notification to/from notification bar
            // tags:
            //      private

            if (oldValue) {
                this.notificationBar.remove(oldValue);
            }

            if (newValue && newValue.content) {
                this.notificationBar.add(newValue);
            }

            this.layout();
        },

        layout: function () {
            // summary:
            //		Layout the pricing overview editor.
            // tags:
            //		protected

            var headerSize = domGeo.getMarginBox(this.header);

            domGeo.setMarginBox(this.priceListNode, {
                h: this._contentBox.h - headerSize.h,
                w: this._contentBox.w
            });
        },

        _setCustomerGroupsAttr: function (customerGroupList) {
            // summary:
            //		Sets customer group list. Let's bind this list to customer groups selector.
            // tags:
            //		private

            // Turn off change notifications while we make all these changes
            this.customerGroupSelector._onChangeActive = false;
            this.customerGroupSelector.removeOption(this.customerGroupSelector.options);

            if (customerGroupList) {
                customerGroupList.unshift(this.defaultCGItem);

                array.forEach(customerGroupList, function (customerGroup) {
                    this.customerGroupSelector.addOption({ label: entities.encode(customerGroup.name), value: entities.encode(customerGroup.id) });
                }, this);
            }

            // Turn on change notifications when we made all these changes
            this.customerGroupSelector._onChangeActive = true;
        },

        _onMarketChanged: function () {
            // summary:
            //      Filter the price list by selected market.
            var val = this.marketSelector.value;

            // Show market column when market seletor is ALL, otherwise hide it.
            if (this.priceList.grid){
                if (val === "ALL") {
                    this.priceList.grid.styleColumn("marketId", "display: table-cell;");
                } else {
                    this.priceList.grid.styleColumn("marketId", "display: none;");
                }
            }

            this.priceList.set("marketId", val);
        },

        _onAddNewPrice: function () {
            // summary:
            //      Add new price to a variation/package.

            var marketId = this.marketSelector.value;
            if (marketId === "ALL") {
                marketId = null;
            }
            var priceCode = this.customerGroupSelector.value;
            if (priceCode === "ALL") {
                priceCode = null;
            }

            var newPrice = this.model.getDefaultPrice(marketId, priceCode);
            this.priceList.addPrice(newPrice);
        },

        _onCustomerGroupChanged: function (){
            // summary:
            //      Filter the price list by selected customer group.
            var val = this.customerGroupSelector.value;

            // Show price type & price code column when customer group seletor is ALL, otherwise hide them.
            if (val === "ALL") {
                this.priceList.grid.styleColumn("priceCode", "display: table-cell;");
                this.priceList.grid.styleColumn("priceType", "display: table-cell;");
            } else {
                this.priceList.grid.styleColumn("priceCode", "display: none;");
                this.priceList.grid.styleColumn("priceType", "display: none;");
            }

            this.priceList.set("priceCode", val);
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: content data
            //      Input content link to get data from.

            this.priceList.set("value", value.id);

            //if the current content type has base type which is variation or package, then show add new price button
            if (TypeDescriptorManager.isBaseTypeIdentifier(value.dataType, ModelSupport.contentTypeIdentifier.variationContent) ||
                TypeDescriptorManager.isBaseTypeIdentifier(value.dataType, ModelSupport.contentTypeIdentifier.packageContent)) {
                domStyle.set(this.addNewPrice.domNode, "display", "");
                this.model.set("value", value.id);
            }
            else {
                domStyle.set(this.addNewPrice.domNode, "display", "none");
            }
        }
    });
});
