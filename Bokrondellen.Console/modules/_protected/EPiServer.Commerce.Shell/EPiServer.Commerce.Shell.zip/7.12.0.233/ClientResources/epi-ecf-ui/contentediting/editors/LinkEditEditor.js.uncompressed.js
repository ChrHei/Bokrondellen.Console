require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/LinkEditEditor.html':"﻿<div class=\"epi-linkeditcollectionediteditor\">\r\n    <h1>${resources.title}</h1>\r\n    <div data-dojo-attach-point=\"collectionList\"></div>\r\n    <div data-dojo-attach-point=\"dropContainer\" class=\"epi-content-area-actionscontainer\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/LinkEditEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",

    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",

    // EPi Framework
    "epi/shell/dnd/Target",
     
    // epi-cms
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",
    //epi_commerce
    "./LinkEditorDndMixin",

    // Resources
    "dojo/text!./templates/LinkEditEditor.html"
],
function (
    //dojo
    declare,
    lang,
    aspect,

    // dijit
    _Widget,
    _TemplatedMixin,

    // EPi Framework
    Target,
    
    // epi-cms
    _TextWithActionLinksMixin,
    //commerce
    LinkEditorDndMixing,
    // Resources
    template
) {
    return declare([_Widget, _TemplatedMixin, _TextWithActionLinksMixin, LinkEditorDndMixing], {

        templateString: template,

        gridCollectionType: null,

        gridCollection: null,

        _dndTarget: null,

        buildRendering: function () {
            this.inherited(arguments);

            this.gridCollection = this.gridCollectionType();

            this._dndTarget = new Target(this.dropContainer, {
                accept: this.gridCollection.allowedDndTypes,
                insertNodes: function () { }
            });
            
            this.own(aspect.after(this._dndTarget, "onDropData", lang.hitch(this, function (dndData) {
                this.gridCollection._addItem(dndData[0], true);
            }), true));

            this.setupDndActions(this._dndTarget, "checkAcceptance");
           
            this.own(this.gridCollection);
            this.collectionList.appendChild(this.gridCollection.domNode);
        },

        postCreate: function () {
            this.inherited(arguments);
            this.setupActionLinks(this.dropContainer);
        },

        getTemplateString: function () {
            // summary:
            //      The template string for drop area
            // tags:
            //      protected

            return {
                templateString: this.resources.drophere,
                actions: this.resources.actions
            };
        },

        updateView: function (data) {
            // summary:
            //		Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //		protected

            this.set("value", data.value);
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: ContentReference
            //      Input content link to get data from.

            this.gridCollection.set("value", value);
        }
    });
});
