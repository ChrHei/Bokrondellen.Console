require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/DateTimeRangeSelector.html':"﻿<div class=\"epi-dateTimeRangeSelector\">\r\n    <div data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\" data-dojo-attach-point=\"fromDateSelector\" data-dojo-props=\"required:true\" data-dojo-attach-event=\"onKeyDown: _handleKey\"></div>\r\n    <div data-dojo-type=\"epi/shell/widget/DateTimeSelectorDropDown\" data-dojo-attach-point=\"toDateSelector\" data-dojo-attach-event=\"onKeyDown: _handleKey\"></div>\r\n</div>\r\n"}});
﻿define("epi-ecf-ui/contentediting/editors/DateTimeRangeSelector", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/keys",
    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/Tooltip",
    "dijit/focus",
    //shell
    "epi/epi",
    "epi/datetime",
    "epi/shell/widget/DateTimeSelectorDropDown",
    //template
    "dojo/text!./templates/DateTimeRangeSelector.html",
    //resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.datetimerangeselector"
],
function (
    // dojo
    declare,
    lang,
    keys,
    // dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    Tooltip,
    focusUtil,
    // epi
    epi,
    datetime,
    DateTimeSelectorDropDown,
    // template
    template,
    // resources
    resources
    ) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        templateString: template,
        resources: resources,

        _fromDateWatchHandle: null,
        _toDateWatchHandle: null,

        value: null,

        constraints: {
            min: '1753-01-01'
        },

        postCreate: function () {
            this.inherited(arguments);

            //Set constraints to date time selector
            this.fromDateSelector.set("constraints", this.constraints);
            this.toDateSelector.set("constraints", this.constraints);

            //Set the custom validation logic and message
            this.toDateSelector.isValid = lang.hitch(this, this.isValid);
        },

        isValid: function () {
            var validFrom = this.fromDateSelector.get("value");
            var validUntil = this.toDateSelector.get("value") || this.toDateSelector.displayedValue;

            // Always get this error message to prevent the error message is set by the last error message.
            this.toDateSelector.invalidMessage = this.toDateSelector.messages.invalidMessage;

            if (!this.fromDateSelector.isInRange() || (validUntil && !this.toDateSelector.isInRange())) {
                return false;
            }

            if (!validUntil){
                return true;
            }

            if (validUntil instanceof Date) {
                if (validUntil > validFrom) {
                    return true;
                }
                else {
                    this.toDateSelector.invalidMessage = resources.validationmessage;
                    return false;
                }
            }

            return false;
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: DateTimeRange
            //      The range of time to display.
            this._set("value", value);
            this.fromDateSelector.set("value", value.validFrom);
            this.toDateSelector.set("value", value.validUntil);
        },

        _getValueAttr: function () {
            var oldValue = this.value;

            var newValue = {
                validFrom: datetime.transformDate(this.fromDateSelector.get("value")),
                validUntil: datetime.transformDate(this.toDateSelector.get("value"))
            };

            if (epi.areEqual(newValue, oldValue)){
                return oldValue;
            } else {
                return newValue;
            }
        },

        _handleKey: function (e) {
            if(e.keyCode === keys.ENTER){
                e.preventDefault();
                focusUtil.curNode.blur();
            }
        },

        focus: function() {
            this.fromDateSelector.focus();
        }
    });
});
