define("epi-ecf-ui/contentediting/editors/PricingOverviewEditor", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/Deferred",

    "dojo/dom-construct",
    "dojo/Stateful",
    "dojo/when",

    // Dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/focus",

    // Dojox
    "dojox/html/entities",

    // DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/extensions/ColumnResizer",
    "dgrid/editor",

    // EPi
    "epi/dependency",
    "epi/string",
    "epi/shell/_ContextMixin",
    "epi/shell/dgrid/_EditorMetadataMixin",
    "epi/shell/widget/_FocusableMixin",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/dialog/Confirmation",

    //epi-CMS
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/formatters",

    // epi commerce
    "../viewmodel/PricingOverviewEditorModel",
    "./SaleCodeEditor",
    "./MoneyEditor",

    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.pricingoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.pricecollection.message"
],
function (
    // Dojo
    array,
    declare,
    lang,

    Deferred,

    domConstruct,
    Stateful,
    when,

    // Dijit
    _LayoutWidget,
    _TemplatedMixin,
    focusUtil,

    // Dojox
    entities,

    // DGrid
    OnDemandGrid,
    Selection,
    ColumnResizer,
    editor,

    // EPi
    dependency,
    epiString,
    _ContextMixin,
    _EditorMetadataMixin,
    _FocusableMixin,
    _ModelBindingMixin,
    Confirmation,

    //epi-CMS
    WithContextMenu,
    formatters,

    // epi commerce
    PricingOverviewEditorModel,
    SaleCodeEditor,
    MoneyEditor,

    // Resources
    resources,
    messageResources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _ModelBindingMixin, _FocusableMixin, _ContextMixin], {

        templateString: '<div class="epi-pricingOverviewEditor" data-dojo-attach-point="gridNode"></div>',

        grid: null,

        modelType: PricingOverviewEditorModel,

        itemType: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.PriceModel",

        activeEditor: null,

        includedColumns: ["Name", "Code", "MarketId", "PriceType", "MinQuantity", "PriceCode", "UnitPrice", "ValidDate"],

        editableColumns: ["MarketId", "PriceType", "MinQuantity", "PriceCode", "UnitPrice", "ValidDate"],

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function() {
            this.inherited(arguments);

            // Set up metadata capable grid type
            var EditorGrid = declare([OnDemandGrid, Selection, editor, _EditorMetadataMixin, ColumnResizer, WithContextMenu], {

                //Todo: Break out to mixin
                getColumnDefinition: function(column) {
                    var columnDef = this.inherited(arguments);

                    //Format text instead value for selector widget
                    if (columnDef.field !== "unitPrice" && column.selections && column.selections.length > 0) {
                        columnDef.renderCell = this._renderSelectorValue(column.selections);
                    }

                    return columnDef;
                },
                //Todo: Break out to mixin
                _renderSelectorValue: function(selections) {
                    return lang.hitch(this, function(item, value, node, options) {
                        selections.some(function(selection) {
                            if (selection.value === value) {
                                node.innerHTML = selection.text;
                                return true;
                            }
                        });

                        if (!node.innerHTML) {
                            node.innerHTML = typeof value === "string" ? entities.encode(value) : value;
                        }
                    });
                }
            });

            // Get metadata for itemType
            when(this.model.metadataManager.getMetadataForType(this.itemType), lang.hitch(this, function(metadata) {
                // Set up columns object with one column for context menu
                var columns = [{
                    field: "epiGridAction",
                    renderHeaderCell: function() {}, // no header
                    formatter: function() {
                        return formatters.menu({
                            title: resources.commands.title
                        });
                    },
                    className: "epi-columnNarrow",
                    sortable: false
                    }],
                    store = dependency.resolve("epi.storeregistry").get("epi.commerce.price"),
                    // Create grid
                    grid = this.grid = new EditorGrid({
                        selectionMode: "single",
                        store: store,
                        minWidth: 100,
                        noDataMessage: resources.nodatamessage,
                        "class": "epi-plain-grid",
                        columns: columns,
                        metadata: {
                            properties: metadata.properties,
                            gridIncluded: this.includedColumns,
                            gridEditable: this.editableColumns
                        }
                    });

                this.model.generateFormatters(grid.columns);
                domConstruct.place(this.grid.domNode, this.gridNode);
                this._setupEvents(grid);

                this._setupContextMenu();

                // Update the grid query in case the contentlink value set but the model or setupEvent hasn't been initialized.
                when(this.getCurrentContext(), lang.hitch(this, function(currentContext){
                    if (this.model.get("contentLink") !== currentContext.id){
                        //we're setting the value, since that will update the models content link
                        //which will update the grids query
                        this.set("value", currentContext.id);
                    } else {
                        //the model already has correct contentLink. Here we just make sure
                        //the grid gets the correct query before starting it
                        this._updateGridQuery(grid);
                    }
                    grid.startup();
                }));
            }));
            this._setMarkets();
        },

        _setupEvents: function(grid){
            var customerPriceGroupType = 2;
            this.own(grid,
                grid.on("dgrid-editor-show", lang.hitch(this, function(e) {
                    if(e.editor instanceof SaleCodeEditor) {
                        //The salecode editor should be updated according to what priceType has been set
                        e.editor.showDropDown(e.cell.row.data.priceType === customerPriceGroupType);
                    } else if (e.editor instanceof MoneyEditor){
                        this._setCurrencySelections(e);
                    }
                    this.activeEditor = e.editor;
                })),
                grid.on("dgrid-datachange", lang.hitch(this, function(e){
                    // when pricetype is changed to/from customer price group clear priceCode value
                    if (e.cell.column.field === "priceType" && (e.value === customerPriceGroupType || e.oldValue === customerPriceGroupType)){
                        e.cell.row.data.priceCode = "";
                    }

                    //invalid value / validation error will result in no changes to the price row
                    if (this.activeEditor && this.activeEditor.isValid && !this.activeEditor.isValid()) {
                        e.preventDefault();
                    }
                })),
                this.model.watch("contentLink", lang.hitch(this, this._changeGridQuery)),
                this.model.watch("marketId", lang.hitch(this, this._changeGridQuery)),
                this.model.watch("priceCode", lang.hitch(this, this._changeGridQuery)),
                this.model.on("itemAdded", lang.hitch(this, function(e) {
                    when(this.grid.refresh(), lang.hitch(this, function(){
                        //if there is only one item after something has been added, there is no need to put it on top.
                        if (this.grid._total === 1){
                            return;
                        }
                        var newRow = this.grid.row(e.id);
                        if (newRow){
                            // Move row to top by doing insertRow to parent with parent's first child as beforeNode argument
                            var parentNode = newRow.element.parentNode;
                            newRow = this.grid.insertRow(newRow.data, parentNode, parentNode.firstChild, 1, {});
                            // Select row
                            this.grid.select(newRow);
                            focusUtil.focus(this.grid.domNode);
                        }
                    }));
                })),
                this.model.on("itemsRemoved", lang.hitch(this, function(e) {
                    this.grid.refresh();
                })),
                // Listen remove command event
                this.model.on("removeCommandEvent", lang.hitch(this, function() {
                    // Show confirmation dialog to confirm delete price item
                    when(this._showConfirmation(resources.deleteconfirmation.pricetitle, resources.deleteconfirmation.pricedescription), lang.hitch(this, function() {
                        if (this.model) {
                            var remove = [];
                            for (var selected in this.grid.selection) {
                                if (this.grid.selection.hasOwnProperty(selected)) {
                                    remove.push(this.model.store.get(selected));
                                }
                            }
                            return this.model.removeItems(remove);
                        }
                    }));
                })),
                this.model.on("duplicateCommandEvent", lang.hitch(this, function() {
                    var row = this._getSelectedRow(),
                        price = row.data,
                        rowElement = row.element;

                    if (price && this.model) {
                        // Clone the model and remove its ID so that JsonRest understands this is a new object
                        // and not an attempt to update an existing object
                        var clone = lang.clone(price);
                        delete clone.id;

                        this.model.addItem(clone);
                    }
                }))
            );
        },

        _updateGridQuery: function (grid) {
            // summary:
            //      update the query for grid.
            //  tags:
            //      private

            var queryOptions = this.model._createQueryOptions();
            grid.set("query", queryOptions.query, queryOptions.options);
        },

        _changeGridQuery: function (property, oldValue, newValue) {
            // summary:
            //      event to update the grid query.
            //  tags:
            //      private

            if (oldValue !== newValue) {
                this._updateGridQuery(this.grid);
            }
        },

        _setCurrencySelections: function(e){
            //the curreny editor should only show currencies that match the current selected market.
            var currentCurrencyCode = e.cell.row.data.unitPrice.currency;
            var currentCurrency = null;
            array.some(e.editor.get("selections"), function(selection){
                if (selection.value === currentCurrencyCode){
                    currentCurrency = selection;
                    return true;
                }
            });

            var market = this._getMarket(e.cell.row.data.marketId);
            if (market) {
                //create a copy of the array so that we can add values to if without affecting the market currencies
                var currenciesForSelectedMarket = market.currencies.slice(0);
                if(currentCurrency){
                    var marketHasCurrentCurrency = array.some(currenciesForSelectedMarket, function(currency){
                        return currency.value === currentCurrency.value;
                    });
                    //if the current currency does not exist in the selected market, we will add that currency as a selection.
                    if (!marketHasCurrentCurrency){
                        currenciesForSelectedMarket.push(currentCurrency);
                    }
                }
                e.editor.set("selections", currenciesForSelectedMarket);
                //sometimes setting selections seems to clear the value of the selection editor
                e.editor.set("value", e.cell.row.data.unitPrice);
            }
        },

        _setupContextMenu: function(){
            this.commands = this.model.getCommands(this.grid, "context");

            this.grid.contextMenu.addProvider(new Stateful({
                commands: this.commands
            }));
        },

        _setMarkets: function(){
            if(!this.get("markets")){
                var marketStore = dependency.resolve("epi.storeregistry").get("epi.commerce.market");
                marketStore.query().then(lang.hitch(this, function(marketList){
                    this.set("markets", marketList);
                }));
            }
        },

        _getMarket: function(marketId){
            var markets = this.get("markets"),
                market = null;
            array.some(markets, function (m) {
                if (m.id === marketId) {
                    market = m;
                    return true;
                }
            });
            return market;
        },

        _getSelectedRow: function () {
            // summary:
            //      Get current selected row.
            // tags:
            //      private

            return this.grid.row(this._getSelectedRowId());
        },

        _getSelectedRowId: function () {
            // summary:
            //      Get Id of current selected row.
            // tags:
            //      private

            for (var id in this.grid.selection) {
                return id;
            }
        },

        _noDataMessage: resources.nodatamessage,

        _setValueAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this._set("value", value);

            if (this.model) {
                this.model.set("contentLink", value);
            }
        },

        _setMarketIdAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this.model.set("marketId", value);
        },

        _setPriceCodeAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this.model.set("priceCode", value);
        },

        _showConfirmation: function (title, description) {
            // summary:
            //      Wrap epi.shell.widget.dialog.Confirmation for short type
            //      and return deferred object
            // description:
            //      String: Text to display on dialog
            // tags:
            //      private

            var deferred = new Deferred();

            var dialog = new Confirmation({
                destroyOnHide: true,
                title: epiString.toHTML(title),
                description: epiString.toHTML(description),
                onAction: function (confirmed) {
                    if (confirmed) {
                        deferred.resolve();
                    } else {
                        deferred.cancel();
                    }
                }
            });
            dialog.show();

            return deferred.promise;
        },

        addPrice: function (newPrice) {
            // summary:
            //      Add new price to the grid
            // tags:
            //      protected

            // Set default value for marketId column
            var markets = this.get("markets");
            if (!newPrice.marketId && markets && markets.length > 0) {
                var defaultMarket = markets[0];
                newPrice = lang.mixin(newPrice, {
                    marketId: defaultMarket.id,
                    currency: defaultMarket.currencies[0].value
                });
            }

            // Insert new row in grid then edit
            return this.model.addItem(newPrice);
        }
    });
});
