﻿define("epi-ecf-ui/contentediting/viewmodel/AssociationCollectionEditorModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi shell
    "epi/shell/_StatefulGetterSetterMixin",
// epi-ecf-ui
    "./_BaseEntryCollectionEditorModel",
//Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.associationcollectioneditor"
],
function (
//dojo
    declare,
    lang,
    when,
// epi shell
    _StatefulGetterSetterMixin,
// epi-ecf-ui
    _BaseEntryCollectionEditorModel,
// Resources
    res
) {
    return declare([_BaseEntryCollectionEditorModel, _StatefulGetterSetterMixin], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/AssociationCollectionEditorModel
        // summary:
        //      Represents the model for AssocciationCollectionEditor

        storeKey: "epi.commerce.association",

        associationStoreKey: "epi.commerce.associationgroupdefinition",

        resources: res,

        postscript: function () {
            this.inherited(arguments);

            this.associationStore = this.associationStore || this.storeRegistry.get(this.associationStoreKey);
        },

        saveItem: function (model) {
            // This is overriden from the base class, and will be called when one item are updated.
            var promise = when(this.store.get(model.id), lang.hitch(this, function(oldItem)
            {
                // groupName and type are part of id so if they are changed we have to
                // create a new item, otherwise update
                if (oldItem.groupName === model.groupName && oldItem.type === model.type) {
                    return this.store.put(model);
                } else {
                    // Clone the model and remove its ID so that JsonRest understands this is a new object
                    // and not an attempt to update an existing object
                    var clone = lang.clone(model);
                    delete clone.id;
                    return when(this.store.remove(oldItem.id), lang.hitch(this, function () {
                        return this.store.add(clone);
                    }));
                }
            }));

            when(promise, lang.hitch(this, function(data) {
                this.emit("itemSaved", { id: data.id });
            }));

            return promise;
        },

        _setContentLinkAttr: function (value) {
            this._set("contentLink", value);
            // get the list of association group definition for current entry.
            when(this.associationStore.get(value), lang.hitch(this, function (items) {
                this.set("associationGroups", items);
            }));
        }
    });
});