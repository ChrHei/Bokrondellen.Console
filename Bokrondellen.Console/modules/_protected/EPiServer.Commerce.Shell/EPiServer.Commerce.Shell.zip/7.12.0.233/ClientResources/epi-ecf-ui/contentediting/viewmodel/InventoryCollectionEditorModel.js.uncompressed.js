﻿define("epi-ecf-ui/contentediting/viewmodel/InventoryCollectionEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "./ReadOnlyCollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,

    ReadOnlyCollectionEditorModel
) {
    return declare([ReadOnlyCollectionEditorModel], {
        // module: 
        //      epi-ecf-ui/contentediting/viewmodel/InventoryCollectionEditorModel
        // summary:
        //      Represents the model for InventoryCollectionEditor

        _storeKey: "epi.commerce.inventory"
    });
});