﻿define("epi-ecf-ui/contentediting/editors/AssociationGroupSelectionEditor", [
    // dojo
    "dojo/_base/declare",
    // dijit
    "dijit/form/Select",
    // epi
    "epi/dependency",
    // epi commerce
    "./SaleCodeEditor"
], function(
    // dojo
    declare,
    // dijit
    Select,
    // epi
    dependency,
    // epi commerce
    SaleCodeEditor
) {
    return declare([SaleCodeEditor], {

        shouldShowDropDown: true
    });
});